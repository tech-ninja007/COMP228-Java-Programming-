package exercise2;

public abstract class GameTester {
    String name;
    boolean statusOfGameTester;
    // true = fulltime  and false = partime
    public abstract double determineSalary();
}
