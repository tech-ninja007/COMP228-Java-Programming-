package exercise3;

public interface MortgageConstants {
    final int shortTerm = 1;
    final int mediumTerm = 3;
    final int longTerm = 5;
    final String bankName = "City Toronto Bank";
    final double maximumMortgageAmount = 300000;
}
