package excerise1;

import javax.swing.*;

public class App {
    public static void main(String[] args){
        Test demoTest = new Test();
        demoTest.inputAnswer();
    }
}
