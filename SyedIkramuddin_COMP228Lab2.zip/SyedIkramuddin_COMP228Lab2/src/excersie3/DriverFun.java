package excersie3;

public class DriverFun {
    public static void main(String[] args){
        Fun.foo(5,4);
        Fun.foo(5.0,4.4);
        Fun.foo("Hello","World");
    }
}
